# COMP 1516 - Lab 6
# Vilmor Somera
# 10/31/22

import number_work as nw

def main():
    nw.get_square_numbers_between(30,222)
    nw.get_square_numbers_between(529, 611)
    nw.process_user_input()

if __name__ == "__main__":
    main()
